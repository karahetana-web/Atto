#!/bin/bash
set -e
echo 'Building APK for Atto Printer App...'
flutter pub get
flutter build apk --release
echo 'Done! APK is at build/app/outputs/flutter-apk/app-release.apk'
